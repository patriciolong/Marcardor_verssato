</main>
    </div> <footer class="main-footer"> <p>&copy; <?php echo date('Y'); ?> ClockIn. Todos los derechos reservados.</p>
    </footer>

</body>
</html>